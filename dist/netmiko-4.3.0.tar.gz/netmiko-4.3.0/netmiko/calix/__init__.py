from netmiko.calix.calix_b6 import CalixB6SSH, CalixB6Telnet

__all__ = ["CalixB6SSH", "CalixB6Telnet"]
