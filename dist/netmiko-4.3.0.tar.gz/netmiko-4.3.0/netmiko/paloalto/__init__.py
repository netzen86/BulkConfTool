from netmiko.paloalto.paloalto_panos import PaloAltoPanosSSH, PaloAltoPanosTelnet

__all__ = ["PaloAltoPanosSSH", "PaloAltoPanosTelnet"]
